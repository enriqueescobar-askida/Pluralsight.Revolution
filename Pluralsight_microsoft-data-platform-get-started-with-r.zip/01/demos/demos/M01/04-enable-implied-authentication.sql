USE [master];
GO
-- Create Windows login for local Windows group and set default database to demo db
CREATE LOGIN [domain\SQLRUserGroup] FROM WINDOWS WITH DEFAULT_DATABASE=[master];
GO
