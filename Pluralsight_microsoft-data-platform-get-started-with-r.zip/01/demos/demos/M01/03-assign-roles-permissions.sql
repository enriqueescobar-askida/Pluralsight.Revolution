USE [master];
GO
-- Create Windows login for user and set default database to demo db
CREATE LOGIN [DIVN\myRuserA] FROM WINDOWS WITH DEFAULT_DATABASE=[r_demos];
GO
USE [r_demos];
GO
-- Add user login to database
CREATE USER [DIVN\myRuserA] FOR LOGIN [DIVN\myRuserA];
GO
-- Configure default schema for user
ALTER USER [DIVN\myRuserA] WITH DEFAULT_SCHEMA=[dbo];
GO

-- Add user to database roles to grant read, write, and execute DDL permissions
ALTER ROLE [db_datareader] ADD MEMBER [DIVN\myRuserA];
GO
ALTER ROLE [db_datawriter] ADD MEMBER [DIVN\myRuserA];
GO
ALTER ROLE [db_ddladmin] ADD MEMBER [DIVN\myRuserA];
GO
-- Grant permission to execute R to user
GRANT EXECUTE ANY EXTERNAL SCRIPT TO [DIVN\myRuserA];
GO
