library(ggplot2)
library(reshape2)
#reconfigure year and month columns
dataset$Year <- as.character(dataset$Year)
dataset$Month <- factor(dataset$Month, levels = month.name)

#change from wide to long format
dfpivot <- melt(dataset, id.vars = c("Year", "Month"))


ggplot(aes(x = Month,
           y = value,
           group = Year,
           color = Year),
       data = dfpivot) +
  geom_line() +
  facet_wrap( ~ variable, scales = "free") +
  theme(axis.text.x = element_text(angle = 60, hjust = 1))
