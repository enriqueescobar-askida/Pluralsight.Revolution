#install.packages("rnoaa")

station <- c("724846")
wban <- c("53123")
years <- c("2016", "2017")

library("rnoaa")

#check which version of rnoaa installed
ip <- as.data.frame(installed.packages()[, c(1, 3:4)])
rownames(ip) <- NULL
ip <- ip[is.na(ip$Priority), 1:2, drop = FALSE]
pkgVersion <- as.character(ip[which(ip$Package == "rnoaa")[1], "Version"])

weather.list <- list()

for (i in seq_along(years)) {

    list.name <- as.character(years[i])


    weather.year <- isd(usaf = station,
                wban = wban,
                 year = as.numeric(years[i]))

    if (pkgVersion == "0.4.2") {
        weatherDF <- as.data.frame(weather.year[1])
    } else {
        weatherDF <- as.data.frame(weather.year)
    }

    names(weatherDF) <- sub("data.", "", names(weatherDF))

    weatherDF <- weatherDF[1:30]
    weatherDF[, 31] <- years[i]
    colnames(weatherDF)[31] <- "year"

    weather.list[[list.name]] <- weatherDF
}


# append together data for all missions using rbind in do.call()
weather <- do.call(rbind, weather.list)


if (pkgVersion == "0.4.2") {
    weather$date <- as.Date(as.character(weather$date), format = "%Y%m%d")
}

weather$temperature <- weather$temperature / 10