# confirm one path for package library
# should match library referenced in SSIS package
# C:\Program Files\Microsoft SQL Server\MSSQL13.MSSQLSERVER\R_SERVICES\bin\Rscript.exe
# which you must adjust if you are using a named instance or SQL Server 2017
.libPaths()



# install a group of packages from CRAN
packages <- c("rnoaa")


for (p in packages) {
  if (!(p %in% rownames(installed.packages()))){
    install.packages(p)
  }
}

