# adapted from an example by Jose Rey
# https://rpubs.com/joseRey/noaa_weather_station_temperature_hourly_cities_Continentality_Oceanity

#install.packages("rnoaa")

args <- commandArgs(TRUE)

#args <- vector()
#args[1] <- c("724846")
#args[2] <- c("53123")
#args[3] <- c("2016")

library("rnoaa")

#check which version of rnoaa installed
ip <- as.data.frame(installed.packages()[,c(1,3:4)])
rownames(ip) <- NULL
ip <- ip[is.na(ip$Priority),1:2,drop=FALSE]
pkgVersion <- as.character(ip[which(ip$Package == "rnoaa")[1], "Version"])


weather <- isd(usaf=args[1], 
               wban=args[2], 
               year=as.numeric(args[3]))

if(pkgVersion == "0.4.2") {
  weatherDF <- as.data.frame(weather[1])
} else {
  weatherDF <- as.data.frame(weather)
}

names(weatherDF) <-sub("data.","", names(weatherDF))

weatherDF <- weatherDF[1:30]
sqlConnString <- "Driver=SQL Server;Server=(local);Database=r_demos;Trusted_Connection={Yes}"

weatherTable <- "annual_weather"
weatherSQL <- RxSqlServerData(connectionString = sqlConnString,
                              table = weatherTable)

#Load weather data into SQL Server table
rxDataStep(inData = weatherDF, 
           outFile = weatherSQL, 
           append = "rows"
)


