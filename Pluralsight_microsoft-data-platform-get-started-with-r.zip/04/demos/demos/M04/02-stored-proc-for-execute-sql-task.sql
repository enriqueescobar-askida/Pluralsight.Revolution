use r_demos;
go
drop procedure if exists dbo.sp_get_weather;
go
create procedure dbo.sp_get_weather
	  @location varchar(20)
	, @wban varchar(20)
	, @year varchar(4)
as
begin

	execute sp_execute_external_script
	@language = N'R'
	, @script = N'

		library("rnoaa")

		#check which version of rnoaa installed
		ip <- as.data.frame(installed.packages()[,c(1,3:4)])
		rownames(ip) <- NULL
		ip <- ip[is.na(ip$Priority),1:2,drop=FALSE]
		pkgVersion <- as.character(ip[which(ip$Package == "rnoaa")[1], "Version"])

		weather <- isd(usaf=location, 
               wban=wban, 
               year=as.numeric(year))
		
		if(pkgVersion == "0.4.2") {
			  weatherDF <- as.data.frame(weather[1])
			} else {
			  weatherDF <- as.data.frame(weather)
			}

		names(weatherDF) <-sub("data.","", names(weatherDF))

		weatherDF <- weatherDF[1:30]
		sqlConnString <- "Driver=SQL Server;Server=(local);Database=r_demos;Trusted_Connection={Yes}"

		weatherTable <- "annual_weather"
		weatherSQL <- RxSqlServerData(connectionString = sqlConnString,
									  table = weatherTable)

		#Load weather data into SQL Server table
		rxDataStep(inData = weatherDF, 
           outFile = weatherSQL, 
           append = "rows")


	'
	, @params = N'@location nvarchar(20), @wban nvarchar(20), @year nvarchar(4)'
	, @location = @location
	, @wban = @wban
	, @year = @year
	-- no input data set
	-- no output data set
	;

end;
