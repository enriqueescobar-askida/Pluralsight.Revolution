USE [r_demos]
GO


CREATE TABLE [dbo].[cdrProspect](
	[age] [float] NULL,
	[annualincome] [float] NULL,
	[calldroprate] [float] NULL,
	[callfailurerate] [float] NULL,
	[customerid] [float] NULL,
	[customersuspended] [nvarchar](255) NULL,
	[education] [nvarchar](255) NULL,
	[gender] [nvarchar](255) NULL,
	[homeowner] [nvarchar](255) NULL,
	[maritalstatus] [nvarchar](255) NULL,
	[monthlybilledamount] [float] NULL,
	[numberofcomplaints] [nvarchar](255) NULL,
	[numberofmonthunpaid] [nvarchar](255) NULL,
	[numdayscontractequipmentplanexpiring] [float] NULL,
	[occupation] [nvarchar](255) NULL,
	[penaltytoswitch] [float] NULL,
	[state] [nvarchar](255) NULL,
	[totalminsusedinlastmonth] [float] NULL,
	[unpaidbalance] [float] NULL,
	[usesinternetservice] [nvarchar](255) NULL,
	[usesvoiceservice] [nvarchar](255) NULL,
	[percentagecalloutsidenetwork] [float] NULL,
	[totalcallduration] [float] NULL,
	[avgcallduration] [float] NULL,
	[churn] [nvarchar](255) NULL
) ;

GO
USE [r_demos]
GO

INSERT INTO [dbo].[cdrProspect]
           ([age]
           ,[annualincome]
           ,[calldroprate]
           ,[callfailurerate]
           ,[customerid]
           ,[customersuspended]
           ,[education]
           ,[gender]
           ,[homeowner]
           ,[maritalstatus]
           ,[monthlybilledamount]
           ,[numberofcomplaints]
           ,[numberofmonthunpaid]
           ,[numdayscontractequipmentplanexpiring]
           ,[occupation]
           ,[penaltytoswitch]
           ,[state]
           ,[totalminsusedinlastmonth]
           ,[unpaidbalance]
           ,[usesinternetservice]
           ,[usesvoiceservice]
           ,[percentagecalloutsidenetwork]
           ,[totalcallduration]
           ,[avgcallduration]
           ,[churn])
     VALUES
           (52,70000,0,0.01,15432,'No','Bachelor or equivalent',
		   	'Female','Yes',	'Married',65,1,2,10,'Technology Related Job',
			400,'CA', 1200,	123,'Yes','Yes', 0.25, 5000,500, NULL);
GO






