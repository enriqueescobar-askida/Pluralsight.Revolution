USE [r_demos]
GO


EXECUTE [dbo].[get_cdr_plot] 
GO


