EXECUTE sp_execute_external_script
@language = N'R',
@script = N' 
   str (InputDataSet);
   OutputDataSet  <- InputDataSet;',
@input_data_1 = N'
 SELECT 
	  [age]
      ,[education]
      ,[gender]
      ,getdate() as CurrentDate
FROM [telco_demo].[dbo].[cdr];'
WITH RESULT SETS undefined;