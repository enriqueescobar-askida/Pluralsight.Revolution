use r_demos;
go

create procedure [dbo].[get_cdr_plot]
as
begin

execute sp_execute_external_script
@language = N'R'
, @script = N'

# Find the numeric columns and create a data frame 
numeric_cols <- sapply(InputDataSet, is.numeric)

library("ggplot2")
library("reshape2")
cdrpivot <- melt(InputDataSet[, numeric_cols], id.vars = c("churn"))

image_file = tempfile();
jpeg(filename = image_file, width=1400, height = 1866);

print(ggplot(aes(x = value,
           group = churn,
           color = factor(churn)),
       data = cdrpivot) +
       geom_density() +
       facet_wrap(~variable, scales = "free"))
dev.off();
OutputDataSet <- data.frame(data=readBin(file(image_file, "rb"), what=raw(), n=1e6));
'
, @input_data_1 = N'
	SELECT [age]
      ,[annualincome]
      ,[calldroprate]
      ,[callfailurerate]
      ,[callingnum]
      ,[customerid]
      ,[customersuspended]
      ,[education]
      ,[gender]
      ,[homeowner]
      ,[maritalstatus]
      ,[monthlybilledamount]
      ,[noadditionallines]
      ,[numberofcomplaints]
      ,[numberofmonthunpaid]
      ,[numdayscontractequipmentplanexpiring]
      ,[occupation]
      ,[penaltytoswitch]
      ,[state]
      ,[totalminsusedinlastmonth]
      ,[unpaidbalance]
      ,[usesinternetservice]
      ,[usesvoiceservice]
      ,[percentagecalloutsidenetwork]
      ,[totalcallduration]
      ,[avgcallduration]
      ,[churn]
      ,[year]
      ,[month]
  FROM [dbo].[cdr];
'
with result sets ((plot varbinary(max)));

end;