use r_demos;
go

execute sp_execute_external_script
@language = N'R'
, @script = N'

numeric_cols <- sapply(InputDataSet, is.numeric)

library("ggplot2")
library("reshape2")
cdrpivot <- melt(InputDataSet[, numeric_cols], id.vars = c("churn"))
OutputDataSet <-head(cdrpivot, 5)
'
, @input_data_1 = N'
	SELECT [age]
      ,[annualincome]
      ,[calldroprate]
      ,[callfailurerate]
      ,[callingnum]
      ,[customerid]
      ,[customersuspended]
      ,[education]
      ,[gender]
      ,[homeowner]
      ,[maritalstatus]
      ,[monthlybilledamount]
      ,[noadditionallines]
      ,[numberofcomplaints]
      ,[numberofmonthunpaid]
      ,[numdayscontractequipmentplanexpiring]
      ,[occupation]
      ,[penaltytoswitch]
      ,[state]
      ,[totalminsusedinlastmonth]
      ,[unpaidbalance]
      ,[usesinternetservice]
      ,[usesvoiceservice]
      ,[percentagecalloutsidenetwork]
      ,[totalcallduration]
      ,[avgcallduration]
      ,[churn]
      ,[year]
      ,[month]
  FROM [dbo].[cdr];
'
with result sets ((churn int not null, variable varchar not null, value float not null));
