exec sp_execute_external_script 
@language=N'R',
@script=N'OutputDataSet<-InputDataSet',
@input_data_1 = N'select 1 as hello'
with result sets (([hello] int not null));
