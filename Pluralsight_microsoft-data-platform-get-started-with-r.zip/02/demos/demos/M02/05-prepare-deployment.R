sqlConnString <- "Driver=SQL Server;Server=<server>;Database=r_demos;Trusted_Connection={Yes}"
cdrTable <- "cdr"

cdrSQL <- RxSqlServerData(connectionString = sqlConnString,
                          table = cdrTable
)

#create a data frame from the SQL Server table
cdrDF <- rxImport(cdrSQL)

#### All of the above is unnecessary when calling T-SQL Stored Procedure

# Find the numeric columns and create a data frame 
numeric_cols <- sapply(cdrDF, is.numeric)

### do not install packages in script
#if (!("reshape2" %in% rownames(installed.packages()))) {
#    install.packages("reshape2")
# }

library("ggplot2")
library("reshape2")
cdrpivot <- melt(cdrDF[, numeric_cols], id.vars = c("churn"))

ggplot(aes(x = value,
           group = churn,
           color = factor(churn)),
       data = cdrpivot) +
       geom_density() +
       facet_wrap(~variable, scales = "free")
