--10-native-scoring.sql
use r_demos;
go

DECLARE @model VARBINARY(MAX) = 
	(select [value] from cdr_models 
		where [id] = 'rxS_DecisionForest');

SELECT d.customerid, p.* 
FROM PREDICT(
		MODEL = @model, 
		DATA = dbo.cdrTest AS d) 
WITH ([0_prob] float, [1_prob] float, churn_Pred nvarchar(max)) AS p;
GO

-- the predict function does not return same columns as you see in R IDE
-- if execute the statement with erroneous column names, 
-- the correct schema displays in the eror message