--05-generate-model.sql

use r_demos;
go

insert into cdr_models ([value])
exec sp_generate_cdr_model;

update cdr_models 
set [id] = 'DecisionForest'
where [id] = 'new model';

select * from cdr_models;
go