sqlConnString <- "Driver=SQL Server;Server=<server>;Database=r_demos;Trusted_Connection={Yes}"

sqlWait <- TRUE
sqlConsoleOutput <- FALSE
sqlShareDir <- paste("c:\\demos\\", Sys.getenv("USERNAME"), sep = "")
sqlCompute <- RxInSqlServer(
  connectionString = sqlConnString,
  wait = sqlWait,
  consoleOutput = sqlConsoleOutput)

cdrColInfo <- list(age = list(type = "integer"),
                   annualincome = list(type = "integer"),
                   calldroprate = list(type = "numeric"),
                   callfailurerate = list(type = "numeric"),
                   callingnum = list(type = "numeric"),
                   customerid = list(type = "integer"),
                   customersuspended = list(type = "factor", levels = c("No", "Yes")),
                   education = list(type = "factor", levels = c("Bachelor or equivalent",
                    "High School or below",
                    "Master or equivalent",
                    "PhD or equivalent")),
                   gender = list(type = "factor", levels = c("Female", "Male")),
                   homeowner = list(type = "factor", levels = c("No", "Yes")),
                   maritalstatus = list(type = "factor", levels = c("Married", "Single")),
                   monthlybilledamount = list(type = "integer"),
                   noadditionallines = list(type = "factor", levels = c("\\N")),
                   numberofcomplaints = list(type = "factor", levels = as.character(0:3)),
                   numberofmonthunpaid = list(type = "factor", levels = as.character(0:7)),
                   numdayscontractequipmentplanexpiring = list(type = "integer"),
                   occupation = list(type = "factor", levels = c("Non-technology Related Job",
                    "Others",
                    "Technology Related Job")),
                   penaltytoswitch = list(type = "integer"),
                   state = list(type = "factor",
                                levels = c("AK", "AL", "AR", "AZ", "CA", "CO", "CT", "DE", "FL", "GA", "HI", "IA", "ID",
                                           "IL", "IN", "KS", "KY", "LA", "MA", "MD", "ME", "MI", "MN", "MO", "MS", "MT", "NC", "ND", "NE", "NH", "NJ", "NM", "NV",
                                           "NY", "OH", "OK", "OR", "PA", "RI", "SC", "SD", "TN", "TX", "UT", "VA", "VT", "WA", "WI", "WV", "WY")),
                   totalminsusedinlastmonth = list(type = "integer"),
                   unpaidbalance = list(type = "integer"),
                   usesinternetservice = list(type = "factor", levels = c("No", "Yes")),
                   usesvoiceservice = list(type = "factor", levels = c("No", "Yes")),
                   percentagecalloutsidenetwork = list(type = "numeric"),
                   totalcallduration = list(type = "integer"),
                   avgcallduration = list(type = "integer"),
                   churn = list(type = "integer"),
                   year = list(type = "factor", levels = as.character(2015)),
                   month = list(type = "factor", levels = as.character(1:3)))

cdrTrainColInfo <- cdrColInfo
cdrTrainColInfo[["callingnum"]] <- NULL
cdrTrainColInfo[["noadditionallines"]] <- NULL
cdrTrainColInfo[["year"]] <- NULL
cdrTrainColInfo[["month"]] <- NULL