# Set the working directory for the demo data and load common variables
wd <- "C:\\demos\\M03"
source(file.path(wd, "00-load-common-variables.R"))


cdrTable <- "cdr"
cdrSQL <- RxSqlServerData(connectionString = sqlConnString,
                          table = cdrTable,
                          colInfo = cdrColInfo)

# perform data preparation steps as needed
# 1. delete unneeded columns
dataColumns <- rxGetVarNames(cdrSQL)
dataColumns <- dataColumns[!dataColumns %in% c("callingnum", "noadditionallines", "year", "month")]
dataColumns <- paste(dataColumns, collapse = ", ")
cdrQuery <- paste("select", dataColumns, " from ", cdrTable)

sourceSQL <- RxSqlServerData(sqlQuery = cdrQuery,
                             connectionString = sqlConnString,
                             colInfo = cdrColInfo)

# 2. clean missing values
cdrDF <- rxDataStep(inData = sourceSQL,
                        removeMissings = TRUE,
                        overwrite = TRUE)

# 3. remove duplicate rows
cdrDF <- cdrDF[!duplicated(cdrDF),]

# 4. split into train and test data
rxSetComputeContext("local")
set.seed(2018)
splitList <- rxSplit(
                    inData = cdrDF,
                    splitByFactor = "splitLabel",
                    transforms = list(splitLabel =
                                      factor(sample(0:1,
                                             size = .rxNumRows,
                                             replace = TRUE,
                                             prob = c(0.7, 0.3)),
                                             levels = 0:1,
                                             labels = c("Train", "Test"))),
                    overwrite = TRUE
                )

trainDF <- rxDataStep(inData = splitList[[1]], varsToDrop = c("splitLabel"))
testDF <- rxDataStep(inData = splitList[[2]], varsToDrop = c("splitLabel"))

# SMOTE train data (synthetic minority over-sampling technique)
# adjustment for unbalanced dataset
if (!("unbalanced" %in% rownames(installed.packages()))) {
    install.packages("unbalanced")
}
library(unbalanced)

trainVars <- names(trainDF)
predictVar = trainVars %in% c("churn")
smoteData <- ubSMOTE(X = trainDF[!predictVar],
                     Y = as.factor(trainDF$churn),
                     perc.over = 200,
                     perc.under = 500,
                     k = 3,
                     verbose = TRUE)

smoteDF <- cbind(smoteData$X, smoteData$Y)
names(smoteDF)[names(smoteDF)=="smoteData$Y"] <- "churn"

# load data in SQL Server tables
trainTable = "cdrTrain"
testTable = "cdrTest"

trainSQL <- RxSqlServerData(connectionString = sqlConnString,
                          table = trainTable,
                          colInfo = cdrTrainColInfo)
testSQL <- RxSqlServerData(connectionString = sqlConnString,
                          table = testTable,
                          colInfo = cdrTrainColInfo)
rxDataStep(inData = smoteDF, outFile = trainSQL, overwrite = TRUE)
rxDataStep(inData = testDF, outFile = testSQL, overwrite = TRUE)

