--06-created-stored-proc-predict-churn.sql
use r_demos;
go

drop procedure if exists dbo.sp_predict_churn_decision_forest;
go

create procedure dbo.sp_predict_churn_decision_forest (@inquery nvarchar(max))
as
begin
	declare @df_churn_model varbinary(max) =
		(select [value] from cdr_models 
		where [id] = 'DecisionForest');

	execute sp_execute_external_script
	@language = N'R',
	@script = N'
	require("RevoScaleR")
	churn_model <- unserialize(df_churn_model)
	predictChurn <- rxPredict(modelObject = churn_model,
                          data = InputDataSet,
                          type = "prob",
                          overwrite = TRUE)
	predictChurn$X0_prob <- NULL
	predictChurn$churn_Pred <- NULL
	names(predictChurn) <- "churn_probability"
	threshold <- 0.6

	predictChurn$churn_prediction <- ifelse(predictChurn$churn_probability > threshold, 1, 0)
	predictChurn$churn_prediction <- factor(predictChurn$churn_prediction, levels = c(1, 0))
	
	OutputDataSet <- cbind(InputDataSet[, c("customerid")], predictChurn)
	',
	@input_data_1 = @inquery,
	@params = N'@df_churn_model varbinary(max)',
	@df_churn_model = @df_churn_model
	with result sets ((
						"customerid" int,
						"churn_probability" float,
						"churn_prediction" int));
end;
go
