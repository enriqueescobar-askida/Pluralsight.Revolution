--09-generative-native-scoring-model.sql
use r_demos;
go

insert into cdr_models ([value])
exec sp_generate_cdr_native_scoring_model;

update cdr_models 
set [id] = 'rxS_DecisionForest'
where [id] = 'new model';

select * from cdr_models;
go

