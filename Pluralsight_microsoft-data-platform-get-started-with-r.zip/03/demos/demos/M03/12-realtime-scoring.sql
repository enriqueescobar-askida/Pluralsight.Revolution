--12 realtime-scoring.sql
use r_demos;
go


SELECT * FROM sys.configurations
WHERE name = 'clr enabled'
go


DECLARE @model VARBINARY(MAX) = 
	(select [value] from cdr_models 
		where [id] = 'rxS_DecisionForest');


EXEC sp_rxPredict
@model = @model,
@inputData = N'SELECT * FROM cdrTest';



