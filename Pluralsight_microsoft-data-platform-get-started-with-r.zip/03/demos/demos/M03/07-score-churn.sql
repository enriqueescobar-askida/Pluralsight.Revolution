use r_demos;
go

exec dbo.sp_predict_churn_decision_forest
@inquery = N'select 
					age, annualincome, calldroprate, callfailurerate, 
					customerid, customersuspended, education, gender, 
					homeowner, maritalstatus, monthlybilledamount, numberofcomplaints, 
					numberofmonthunpaid, numdayscontractequipmentplanexpiring, 
					occupation, penaltytoswitch, state, totalminsusedinlastmonth, 
					unpaidbalance, usesinternetservice, usesvoiceservice, 
					percentagecalloutsidenetwork, totalcallduration, avgcallduration, 
					churn from cdrTest;'
;
GO