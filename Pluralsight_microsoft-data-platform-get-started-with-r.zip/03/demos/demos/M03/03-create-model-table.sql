-- 03-create-model-table.sql

use r_demos;
go

drop table if exists cdr_models;
go
create table cdr_models (
   [id] varchar(30) not null default ('new model') primary key,
   [value] varbinary(max) not null
);
go