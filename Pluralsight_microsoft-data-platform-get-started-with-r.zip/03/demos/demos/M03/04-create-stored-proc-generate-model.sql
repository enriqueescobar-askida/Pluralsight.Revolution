-- 04-create-stored-proc-generate-model.sql

use r_demos;
go

drop procedure if exists dbo.sp_generate_cdr_model;
go

create procedure dbo.sp_generate_cdr_model
as
begin
	execute sp_execute_external_script
	@language = N'R',
	@script = N'
	require("RevoScaleR")
	predictVar = "churn"
	idVar = "customerid"
	#combine these variables into a vector
	removeVars = c(predictVar, idVar)
	
	trainVars <- rxGetVarNames(InputDataSet)
	trainVars <- trainVars[!trainVars %in% c(removeVars)]

	formula_string <- paste(c(predictVar, paste(trainVars, collapse = "+")), collapse = "~")
	formula <- as.formula(formula_string)

	decision_forest_model <- rxDForest(formula = formula,
									   data = InputDataSet,
									   nTree = 8,
									   maxDepth = 32,
									   mTry = 2,
									   minBucket = 1,
									   maxNumBins = 1001,
									   replace = TRUE,
									   importance = TRUE,
									   seed = 8,
									   parms = list(loss = c(0, 4, 1, 0)),
                    method="class"
									   )
	OutputDataSet <- data.frame(payload = as.raw(serialize(decision_forest_model, connection=NULL)));
	

	',
	@input_data_1 = N'select 
					age, annualincome, calldroprate, callfailurerate, 
					customerid, customersuspended, education, gender, 
					homeowner, maritalstatus, monthlybilledamount, numberofcomplaints, 
					numberofmonthunpaid, numdayscontractequipmentplanexpiring, 
					occupation, penaltytoswitch, state, totalminsusedinlastmonth, 
					unpaidbalance, usesinternetservice, usesvoiceservice, 
					percentagecalloutsidenetwork, totalcallduration, avgcallduration, 
					churn from cdrTrain;'
	with result sets ((model varbinary(max)));
end;

