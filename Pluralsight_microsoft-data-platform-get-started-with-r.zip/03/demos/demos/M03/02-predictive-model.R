# Set the working directory for the demo data and load common variables
wd <- "C:\\demos\\M03"
source(file.path(wd, "00-load-common-variables.R"))

rxSetComputeContext('local')

cdrTrainTable <- "cdrTrain"
cdrTrainSQL <- RxSqlServerData(connectionString = sqlConnString,
                          table = cdrTrainTable,
                          colInfo = cdrTrainColInfo)
#identify variables with variable to predict and observation identifier
predictVar = "churn"
idVar = "customerid"
#combine these variables into a vector
removeVars = c(predictVar, idVar)
#get the variable names from the table and remove the variables above
trainVars <- rxGetVarNames(cdrTrainSQL)
trainVars <- trainVars[!trainVars %in% c(removeVars)]

#set up formula for model
formula_string <- paste(c(predictVar, paste(trainVars, collapse = "+")), collapse = "~")
formula <- as.formula(formula_string)

# generate Decision Forest model
library(RevoScaleR)
decision_forest_model <- rxDForest(formula = formula,
                                   data = cdrTrainSQL,
                                   nTree = 8,
                                   maxDepth = 32,
                                   mTry = 2,
                                   minBucket = 1,
                                   maxNumBins = 1001,
                                   replace = TRUE,
                                   importance = TRUE,
                                   seed = 8,
                                   parms = list(loss = c(0, 4, 1, 0)),
                                   method="class"
                                   )


# review model results
decision_forest_model
summary(decision_forest_model)
plot(decision_forest_model)
rxVarImpPlot(decision_forest_model)

# apply model to test data 
cdrTestTable <- "cdrTest"
cdrTestSQL <- RxSqlServerData(connectionString = sqlConnString,
                          table = cdrTestTable,
                          colInfo = cdrTrainColInfo)
testDF <- rxImport(inData = cdrTestSQL, outFile = NULL, colInfo = cdrTrainColInfo)

predictChurn <- rxPredict(modelObject = decision_forest_model,
                          data = testDF,
                          #data = cdrTestSQL,
                          type = "prob",
                          overwrite = TRUE)

# restructure the output of rxPredict
predictChurn$X0_prob <- NULL
predictChurn$churn_Pred <- NULL
names(predictChurn) <- "churn_probability"
threshold <- 0.6

predictChurn$churn_prediction <- ifelse(predictChurn$churn_probability > threshold, 1, 0)
predictChurn$churn_prediction <- factor(predictChurn$churn_prediction, levels = c(1, 0))
predictionDF <- cbind(testDF[, c("customerid", "churn")], predictChurn)

# evaluate model
confusion_matrix <- table(predictionDF[["churn"]], predictionDF[["churn_prediction"]])
print(confusion_matrix)

true_positive <- confusion_matrix[rownames(confusion_matrix) == 1, colnames(confusion_matrix) == 1]
false_positive <- confusion_matrix[rownames(confusion_matrix) == 0, colnames(confusion_matrix) == 1]
true_negative <- confusion_matrix[rownames(confusion_matrix) == 0, colnames(confusion_matrix) == 0]
false_negative <- confusion_matrix[rownames(confusion_matrix) == 1, colnames(confusion_matrix) == 0]


metrics <- c("Accuracy", "Precision", "Recall", "FScore")
accuracy <- (true_positive + true_negative) /
                (true_positive + true_negative + false_positive + false_negative)
precision <- true_positive / (true_positive + false_positive)
recall <- true_positive / (true_positive + false_negative)
fscore <- 2 * (precision * recall) / (precision + recall)

value = c(accuracy, precision, recall, fscore)
model_perf <- data.frame(metrics, value)
model_perf

testData <- predictionDF[, c("churn", "churn_probability")]
testData[[c("churn")]] <- as.numeric(as.character(testData[[c("churn")]]))

rxRocCurve(actualVarName = "churn",
    predVarNames = "churn_probability",
    data = testData)

